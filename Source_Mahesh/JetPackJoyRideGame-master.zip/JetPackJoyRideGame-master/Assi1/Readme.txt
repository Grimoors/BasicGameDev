This is a type of jetpack joyride
    You have 3 lives in it
for running 
    python3 run.py
movements
    for right press 'd'
    for left press 'a'
    for up press 'w'
    gravity is there for down effect
features
    for shield press space bar and shield lasts for 15 seconds and to use again you have to wait for 60 sec
    for powerup press 'x' and powerup lasts for 10 seconds and to use again you have to wait for 30 sec
    for drogon press 'h' and dragon appears only after half game is over i.e you can see weather you can activate or not in screen