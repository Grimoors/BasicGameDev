if "__name__" == "__main__":
    print("This module at \"/src/\" cannot run standalone")
else:
    print("Hi Fer")
    print(__name__)