if "__name__" != "__main__":
    a=1
else:
    print("This module at \"/src/\" cannot run standalone")