if "__name__" != "__main__":
    1=1
else:
    print("This module at \"/src/\" cannot run standalone")