if "__name__" != "__main__":
    #Import Necessities

    #Define a Screen Area , A Border, A Content, 
    print()
else:
    print("This module \'./src/scenes/scene.py\' cannot run as standalone ")