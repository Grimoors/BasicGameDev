if "__name__" != "__main__":
    a=1
else:
    print("This module at \"/src/\" can only run standalone")