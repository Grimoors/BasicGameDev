# THE MANDALORIAN : THE GAME

This is an terminal-based arcade game designed in python3 using OOPS concepts.

## DIRECTORIES or FILES INCLUDED

### 2018101042

Contains everything that has been submitted or will be submitted

### Testing

Contains sub-sections of code or random pieces of code just for checking the functions utility

### ideas.md

Contains all my ideas related to the classes built and so on

### guide.md

Contains details on how I did the assignment

### assignment_1.pdf

Contains the problem statement of the assignment.
