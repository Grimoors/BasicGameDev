# https://en.wikibooks.org/wiki/Python_Programming/Text

if __name__ == "__main__":
    c=input()
    print(ord(c))
    print(chr(ord(c)))
    